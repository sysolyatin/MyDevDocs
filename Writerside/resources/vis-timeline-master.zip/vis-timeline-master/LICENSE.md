# License

Copyright (c) 2014-2017 Almende B.V. and contributors
Copyright (c) 2017-2019 vis.js contributors

This work is dual-licensed under [Apache-2.0](./LICENSE.Apache-2.0.txt) and [MIT](./LICENSE.MIT.txt).
You can choose between one of them if you use this work.

`SPDX-License-Identifier: Apache-2.0 OR MIT`
